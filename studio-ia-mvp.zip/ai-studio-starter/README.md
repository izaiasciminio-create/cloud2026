# Studio IA - MVP 1

Estúdio web responsivo para criar prompts de vídeo realista. Não usa API paga e não gera vídeos diretamente.

## Requisitos
Node.js 20.9+ e npm.

## Iniciar
```bash
npm install
npm run dev
```
Abra http://localhost:3000

## Arquitetura
- Next.js App Router + TypeScript
- `app/page.tsx`: formulário e visualização do prompt
- `app/api/prompts/route.ts`: validação e geração de prompts
- `lib/prompt.ts`: regras de composição do prompt
- `app/style.css`: tema responsivo

## Próximas etapas
- Login e persistência de projetos (Supabase)
- Biblioteca de modelos com referências e consentimento
- Histórico e versões de prompts
- Integração opcional com provedores de geração de vídeo
- Multi-tenant, planos e pagamentos apenas após validar MVP

## Segurança
Não coloque chaves de API no frontend. Este MVP não possui autenticação nem armazenamento persistente e não deve ser publicado como serviço multiusuário sem essas implementações.
