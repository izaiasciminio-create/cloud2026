import './style.css';
export const metadata = { title: 'Studio IA', description: 'Estúdio de prompts para vídeos comerciais' };
export default function Layout({children}:{children:React.ReactNode}) {return <html lang="pt-BR"><body>{children}</body></html>}
