import {NextResponse} from 'next/server';
import {makePrompt, type PromptInput} from '../../../lib/prompt';
export async function POST(req:Request) {
  try {
    const body = await req.json() as PromptInput;
    if (!body || typeof body !== 'object' || ![8,10,15].includes(body.duration)) return NextResponse.json({error:'Duração inválida'}, {status:400});
    for (const field of ['model','product','scene','movement'] as const) if(typeof body[field] !== 'string' || body[field].length > 1000) return NextResponse.json({error:`Campo inválido: ${field}`},{status:400});
    if(typeof body.spoken !== 'boolean') return NextResponse.json({error:'Áudio inválido'}, {status:400});
    return NextResponse.json({prompt:makePrompt(body)});
  } catch {return NextResponse.json({error:'Requisição inválida'},{status:400})}
}
